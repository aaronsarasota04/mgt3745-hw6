import express, { Request, Response, NextFunction } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// F1-10: THE SYSTEM SHALL show only postings and a collection date that the team supplied, and SHALL NOT generate either.
// F1-4: The date the posting set was collected is provided alongside all query results.
const TEAM_SUPPLIED_POSTING_SET = {
  collectionDate: 'October 12, 2026',
  roles: [
    'Junior Software Engineer',
    'Frontend Developer',
    'Backend Developer',
    'Data Analyst',
    'Quality Assurance (QA) Engineer',
    'Cybersecurity Analyst',
    'Site Reliability Engineer (SRE)' // Intentionally has 0 postings to satisfy F1-6
  ],
  postings: [
    {
      id: 'post-101',
      role: 'Junior Software Engineer',
      title: 'Junior Software Engineer',
      company: 'Apex Systems',
      location: 'Boston, MA (Hybrid)',
      datePosted: '2026-10-08',
      skills: ['Python', 'Git', 'SQL', 'Unit Testing', 'REST APIs']
    },
    {
      id: 'post-102',
      role: 'Junior Software Engineer',
      title: 'Associate Software Engineer',
      company: 'Vanguard Tech',
      location: 'New York, NY',
      datePosted: '2026-10-05',
      skills: ['Java', 'Git', 'REST APIs', 'Problem Solving', 'Object-Oriented Programming']
    },
    {
      id: 'post-103',
      role: 'Junior Software Engineer',
      title: 'Entry-Level Software Engineer',
      company: 'Horizon Labs',
      location: 'Austin, TX (Remote)',
      datePosted: '2026-10-10',
      skills: ['Python', 'JavaScript', 'Git', 'REST APIs', 'SQL']
    },
    {
      id: 'post-201',
      role: 'Frontend Developer',
      title: 'Junior Frontend Developer',
      company: 'Beacon Digital',
      location: 'Chicago, IL',
      datePosted: '2026-10-09',
      skills: ['HTML', 'CSS', 'JavaScript', 'React', 'Git']
    },
    {
      id: 'post-202',
      role: 'Frontend Developer',
      title: 'Associate Web Developer',
      company: 'Crestview Media',
      location: 'Remote',
      datePosted: '2026-10-07',
      skills: ['JavaScript', 'TypeScript', 'CSS', 'React', 'Responsive Design', 'Git']
    },
    {
      id: 'post-301',
      role: 'Backend Developer',
      title: 'Junior Backend Developer',
      company: 'CloudScale Inc.',
      location: 'Seattle, WA',
      datePosted: '2026-10-11',
      skills: ['Python', 'Node.js', 'SQL', 'REST APIs', 'Docker', 'Git']
    },
    {
      id: 'post-302',
      role: 'Backend Developer',
      title: 'Entry-Level Backend Engineer',
      company: 'DataStream Solutions',
      location: 'Atlanta, GA',
      datePosted: '2026-10-06',
      skills: ['Node.js', 'PostgreSQL', 'REST APIs', 'Git', 'Redis']
    },
    {
      id: 'post-401',
      role: 'Data Analyst',
      title: 'Junior Healthcare Data Analyst',
      company: 'MetroHealth Analytics',
      location: 'Philadelphia, PA',
      datePosted: '2026-10-09',
      skills: ['SQL', 'Excel', 'Python', 'Tableau', 'Data Visualization']
    },
    {
      id: 'post-402',
      role: 'Data Analyst',
      title: 'Associate Business Intelligence Analyst',
      company: 'Keystone Logistics',
      location: 'Dallas, TX',
      datePosted: '2026-10-04',
      skills: ['SQL', 'Excel', 'Power BI', 'Statistics', 'Problem Solving']
    },
    {
      id: 'post-501',
      role: 'Quality Assurance (QA) Engineer',
      title: 'Junior QA Engineer',
      company: 'Novus Quality Labs',
      location: 'Denver, CO',
      datePosted: '2026-10-08',
      skills: ['Test Automation', 'Python', 'Selenium', 'Git', 'Bug Tracking', 'JIRA']
    },
    {
      id: 'post-502',
      role: 'Quality Assurance (QA) Engineer',
      title: 'Associate Software Test Specialist',
      company: 'BluePeak Software',
      location: 'Remote',
      datePosted: '2026-10-03',
      skills: ['Manual Testing', 'Test Automation', 'SQL', 'Git', 'Bug Tracking']
    },
    {
      id: 'post-601',
      role: 'Cybersecurity Analyst',
      title: 'Associate Information Security Analyst',
      company: 'Sentinel Cyber Defense',
      location: 'Washington, DC',
      datePosted: '2026-10-02',
      skills: ['Network Security', 'Linux', 'Wireshark', 'Incident Response', 'Python', 'Vulnerability Assessment']
    }
  ]
};

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json());

  // F1-9: IF a request from the browser tries to add, change, or delete a posting, THEN THE SYSTEM SHALL refuse it. (PROBE-001 #4)
  // Explanatory comment: We explicitly intercept any non-GET HTTP verb on the /api/postings endpoints and return HTTP 405 Method Not Allowed.
  app.all(['/api/postings', '/api/postings/*'], (req: Request, res: Response, next: NextFunction) => {
    if (req.method !== 'GET') {
      res.setHeader('Allow', 'GET');
      return res.status(405).json({
        refusalMessage: 'Refused: Adding, changing, or deleting postings is strictly prohibited. The team posting set is immutable.',
        prohibitedMethod: req.method,
        status: 405
      });
    }
    next();
  });

  // F1-8: THE SYSTEM SHALL read postings only through the team's own API, and SHALL NOT hold a database key in browser code. (PROBE-001 #1)
  // F1-10: THE SYSTEM SHALL show only postings and a collection date that the team supplied, and SHALL NOT generate either. (PROBE-001 #2)
  app.get('/api/postings', (_req: Request, res: Response) => {
    return res.json({
      collectionDate: TEAM_SUPPLIED_POSTING_SET.collectionDate,
      roles: TEAM_SUPPLIED_POSTING_SET.roles,
      postings: TEAM_SUPPLIED_POSTING_SET.postings
    });
  });

  // Explicit health endpoint
  app.get('/api/health', (_req: Request, res: Response) => {
    return res.json({ status: 'ok', serverTime: new Date().toISOString() });
  });

  // Refuse mutations across any other /api endpoints as a defense-in-depth measure
  app.all('/api/*', (req: Request, res: Response) => {
    if (req.method !== 'GET') {
      res.setHeader('Allow', 'GET');
      return res.status(405).json({
        refusalMessage: 'Refused: API mutations are prohibited.',
        prohibitedMethod: req.method,
        status: 405
      });
    }
    return res.status(404).json({ error: 'Endpoint not found.' });
  });

  // Mount Vite dev server in middleware mode or serve static files in production
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    // Server bound to 0.0.0.0:PORT
  });
}

startServer();
