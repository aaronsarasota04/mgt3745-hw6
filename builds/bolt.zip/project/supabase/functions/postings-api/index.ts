// Edge function: the team's own read-only API for the posting set.
// The browser never holds a database key (F1-8) and never mutates postings
// (F1-9); it only ever calls this function. Writes are refused here at the
// HTTP layer, and the postings table has no write policies so the database
// refuses writes too, regardless of caller.

import { createClient } from "npm:@supabase/supabase-js@2.45.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  // Preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  // F1-9: refuse any non-GET, non-OPTIONS request before it can touch data.
  if (req.method !== "GET") {
    return new Response(
      JSON.stringify({
        error: "Read-only API. Adding, changing, or deleting postings is not allowed.",
      }),
      { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }

  try {
    // The service role key is only present in the edge function's environment,
    // never shipped to the browser. The anon key the browser holds only
    // authorizes calling this function, not direct table access.
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";

    if (!supabaseUrl || !serviceRoleKey) {
      return new Response(
        JSON.stringify({ error: "Server is not configured to read postings." }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const supabase = createClient(supabaseUrl, serviceRoleKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    // Query role + skills + collection date. The service role bypasses RLS,
    // which is correct here because this function IS the trusted team API.
    // The browser never makes this query itself.
    const { data, error } = await supabase
      .from("postings")
      .select("role, skills, collected_on");

    if (error) {
      return new Response(
        JSON.stringify({ error: "Could not read the posting set." }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // Validate shape before binding into the response — a missing column
    // would otherwise produce undefined downstream.
    const rows = Array.isArray(data)
      ? data.filter(
          (row): row is { role: string; skills: string[]; collected_on: string } =>
            row !== null &&
            typeof row.role === "string" &&
            Array.isArray(row.skills) &&
            typeof row.collected_on === "string",
        )
      : [];

    // F1-10: only the team-supplied postings and collection date are returned.
    // Nothing is generated or inferred here.
    return new Response(
      JSON.stringify({ postings: rows }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unexpected server error.";
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
