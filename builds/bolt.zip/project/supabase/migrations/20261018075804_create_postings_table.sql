/*
# Create postings table (read-only posting set for skill-gap analysis)

## Purpose
Stores the team-supplied job posting set used by the Skill Gap feature.
The browser must never hold a database key and must never mutate postings,
so this table is read-only from the anon/authenticated roles: only SELECT
is granted. The team loads postings server-side (service role / dashboard),
never through browser code.

## New Tables
- `postings`
  - `id` (uuid, primary key)
  - `role` (text, not null) — normalized target role, e.g. "Frontend Developer"
  - `title` (text, not null) — the posting's headline title
  - `company` (text, not null) — employer name
  - `skills` (text[], not null) — skills listed in the posting
  - `collected_on` (date, not null) — date the posting set was collected
  - `created_at` (timestamptz, default now())

## Security
- Row Level Security enabled.
- A single SELECT policy scoped to `anon, authenticated` so the no-auth
  frontend can read the team-supplied postings.
- NO insert, update, or delete policies are created. This is intentional:
  F1-9 requires the system to refuse any browser attempt to add, change, or
  delete a posting. With no write policies, RLS denies every write at the
  database layer regardless of what the edge function or client does.

## Important Notes
1. The collection date is stored per posting row; every row in a posting
   set shares the same `collected_on`, so the API returns that shared date
   as the set's collection date (F1-4).
2. Sample postings are seeded below so the feature is exercisable without
   live data. Per F1-10 the app only ever shows team-supplied postings and
   collection dates; nothing is generated at runtime.
*/

CREATE TABLE IF NOT EXISTS postings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  role text NOT NULL,
  title text NOT NULL,
  company text NOT NULL,
  skills text[] NOT NULL,
  collected_on date NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE postings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_read_postings" ON postings;
CREATE POLICY "anon_read_postings"
  ON postings FOR SELECT
  TO anon, authenticated
  USING (true);

-- Index for filtering by role, the primary access path for the skill-gap query.
CREATE INDEX IF NOT EXISTS idx_postings_role ON postings (role);

-- Seed the team-supplied posting set. All rows share one collection date.
INSERT INTO postings (role, title, company, skills, collected_on) VALUES
  ('Frontend Developer', 'Junior Frontend Developer', 'Northwind Labs',
    ARRAY['HTML', 'CSS', 'JavaScript', 'React', 'Git', 'Accessibility'], '2026-09-15'),
  ('Frontend Developer', 'Frontend Engineer I', 'Bluepeak Studio',
    ARRAY['JavaScript', 'TypeScript', 'React', 'CSS', 'REST APIs', 'Git'], '2026-09-15'),
  ('Frontend Developer', 'UI Developer (Entry Level)', 'Cedar Interactive',
    ARRAY['HTML', 'CSS', 'JavaScript', 'React', 'Figma', 'Testing'], '2026-09-15'),
  ('Backend Developer', 'Junior Backend Engineer', 'Atlas Systems',
    ARRAY['Python', 'SQL', 'REST APIs', 'Git', 'Docker', 'Linux'], '2026-09-15'),
  ('Backend Developer', 'Backend Developer I', 'Meridian Pay',
    ARRAY['Java', 'SQL', 'REST APIs', 'Git', 'AWS', 'Docker'], '2026-09-15'),
  ('Data Analyst', 'Entry-Level Data Analyst', 'Pinecrest Analytics',
    ARRAY['SQL', 'Excel', 'Python', 'Tableau', 'Statistics'], '2026-09-15'),
  ('Data Analyst', 'Junior Data Analyst', 'Harbor Insights',
    ARRAY['SQL', 'Python', 'Power BI', 'Statistics', 'Excel'], '2026-09-15'),
  ('DevOps Engineer', 'Junior DevOps Engineer', 'Ironclad Cloud',
    ARRAY['Linux', 'Docker', 'AWS', 'CI/CD', 'Python', 'Git'], '2026-09-15'),
  ('QA Engineer', 'Junior QA Engineer', 'Lumen Quality',
    ARRAY['Testing', 'Selenium', 'Java', 'SQL', 'Bug Tracking'], '2026-09-15')
ON CONFLICT DO NOTHING;
